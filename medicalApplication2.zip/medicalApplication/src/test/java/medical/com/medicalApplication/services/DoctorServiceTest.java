package medical.com.medicalApplication.services;

import org.junit.Test;

import medical.com.medicalApplication.services.DoctorService;

import static org.junit.Assert.*;

public class DoctorServiceTest {

    @Test
    public void addDoctorSimpleTest() {
        DoctorService service = DoctorService.getReference(); // new DoctorService();
        service.addDoctor("name1", "7");
        assertEquals("Doctor Name:name1 ID: 7", service.getAllDoctors().get(0).toString());
        assertEquals(1, service.getAllDoctors().size());
    }

    @Test
    public void addMultipleDoctors() {
        DoctorService service = DoctorService.getReference(); // new DoctorService();
        service.addDoctor("name1", "7");
        service.addDoctor("name2", "10");
        assertEquals("Doctor Name:name1 ID: 7", service.getAllDoctors().get(0).toString());
        assertEquals("Doctor Name:name2 ID: 10", service.getAllDoctors().get(1).toString());
        assertEquals(2, service.getAllDoctors().size());
    }

}
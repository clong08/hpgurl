package medical.com.medicalApplication.model;

//TreatmentTest.java
import org.junit.Test;

import medical.com.medicalApplication.model.Treatment;

import static org.junit.Assert.*;

public class TreatmentTest {
  Treatment treatment = new Treatment("date","diagnose","description");

  @Test
  public void TestGetTreatmentDate(){
      assertEquals(treatment.getTreatmentDate(), "date");
  }

  @Test
  public void TestGetDiagnose(){
      assertEquals(treatment.getDiagnose(), "diagnose");
  }

  @Test
  public void TestGetDescription(){
      assertEquals(treatment.getDescription(), "description");
  }

  @Test
  public void TestToString(){
      assertEquals(treatment.toString(), "Treatment:  Date: date Diagnose: diagnose");
  }
}

package medical.com.medicalApplication.model;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import medical.com.medicalApplication.model.Doctor;

public class doctor {
	Doctor doctor = new Doctor("Doctor name", "Doctor Id");

    @Test
    public void TestGetName(){
        assertEquals(doctor.getName(),"Doctor name");
    }

    @Test
    public void TestGetID(){
        assertEquals(doctor.getId(),"Doctor Id");
    }

    @Test
    public void TestToString(){
        assertEquals(doctor.toString(),"Doctor Name:Doctor name ID: Doctor Id");
    }
}


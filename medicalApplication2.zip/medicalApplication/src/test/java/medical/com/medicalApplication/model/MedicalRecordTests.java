package medical.com.medicalApplication.model;

import static org.junit.Assert.assertNotNull;
import org.junit.Test;

import medical.com.medicalApplication.model.MedicalRecord;
import medical.com.medicalApplication.model.Patient;
public class MedicalRecordTests {
@Test
public void verifyPatientIsNotNull() {
MedicalRecord medRecord = new MedicalRecord( new Patient());
assertNotNull("Patient object is NULL", medRecord.getPatient());
}
@Test
public void verifyPatientHistoryIsNotNull() {
MedicalRecord medRecord = new MedicalRecord( new Patient());
assertNotNull("Patient's History is NULL", medRecord.getPatient());
}
}

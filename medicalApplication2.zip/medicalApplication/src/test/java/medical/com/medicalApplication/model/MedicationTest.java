package medical.com.medicalApplication.model;

//MedicationTest.java
import org.junit.Test;

import medical.com.medicalApplication.model.Medication;

import static org.junit.Assert.*;

public class MedicationTest {
  Medication medication = new Medication("name","start","end","dose");

  @Test
  public void TestGetName(){
      assertEquals(medication.getName(),"name");
  }

  @Test
  public void TestGetStartDate(){
      assertEquals(medication.getStartDate(),"start");
  }

  @Test
  public void TestGetEndDate(){
      assertEquals(medication.getEndDate(),"end");
  }

  @Test
  public void TestGetDose(){
      assertEquals(medication.getDose(),"dose");
  }

  @Test
  public void TestToString(){
      assertEquals(medication.toString(),"Medication:name Start Date: start End Date: end Dose: dose");
  }

}
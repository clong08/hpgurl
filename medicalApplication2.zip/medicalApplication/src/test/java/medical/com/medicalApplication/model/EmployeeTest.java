package medical.com.medicalApplication.model;

import static org.junit.Assert.*;

import org.junit.Test;

import medical.com.medicalApplication.model.Employee;

public class EmployeeTest {
    Employee employee = new Employee("Employee Name","Employee ID");

    @Test
    public void TestGetName(){
        assertEquals(employee.getName(),"Employee Name");
    }

    @Test
    public void TestGetID(){
        assertEquals(employee.getId(),"Employee ID");
    }

    @Test
    public void TestGetPassword(){
        assertEquals(employee.getPassword(),"Open");
    }
}
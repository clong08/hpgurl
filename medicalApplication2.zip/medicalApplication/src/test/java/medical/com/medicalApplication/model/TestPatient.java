package medical.com.medicalApplication.model;

//TestPatient.java
import org.junit.Test;

import medical.com.medicalApplication.model.Patient;

import static org.junit.Assert.*;

public class TestPatient {
  Patient patient = new Patient("name","id");

  @Test
  public void TestGetName(){
      assertEquals(patient.getName(), "name");
  }

  @Test
  public void TestGetID(){
      assertEquals(patient.getId(), "id");
  }

  @Test
  public void TestToString(){
      assertEquals(patient.toString(), "Patient Name: name ID: id");
  }


}
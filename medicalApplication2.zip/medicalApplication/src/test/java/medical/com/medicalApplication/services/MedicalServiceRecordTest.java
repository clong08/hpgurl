package medical.com.medicalApplication.services;

import java.util.Collections;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import medical.com.medicalApplication.model.MedicalRecord;
import medical.com.medicalApplication.model.Patient;
import medical.com.medicalApplication.services.MedicalRescordService;

public class MedicalServiceRecordTest {
   MedicalRescordService reference;

   @Before
   public void setUp(){
       reference = MedicalRescordService.getReference();
   }

   @Test
   public void testAddPatient(){
       Assert.assertTrue(reference.addPatient("Sample1", "001"));
   }

   @Test
   public void testAddDuplicatePatient(){
       Assert.assertFalse(reference.addPatient("Sample1", "001"));
   }

   //Assuming Patient class has a arg constructor which accepts id and name
   @Test
   public void testGetMedicalRecord1(){
       Assert.assertEquals(new Patient("Sample1", "001"), reference.getPatient("001"));
   }

   //Assuming MedicalRecord class has a arg constructor which accepts a patient obj
   @Test
   public void testGetMedicalRecord(){
       Assert.assertEquals(new MedicalRecord(new Patient("Sample1", "001")), reference.getMedicalRecord("001"));
   }

   @Test
   public void testGetAllPatient(){
       Assert.assertEquals(reference.getAllPatients().size(), 1);
   }

   @Test
   public void testGetPatientsWithAllergies(){
       Assert.assertEquals(Collections.emptyList(), reference.getPatientsWithAllergies("allergyName"));
   }
}
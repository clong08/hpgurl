package medical.com.medicalApplication.model;

import static org.junit.Assert.*;
import org.junit.Test;

import medical.com.medicalApplication.model.Allergey;

public class AllergyTest {
    Allergey allergey = new Allergey("AllergyName");

    @Test
    public void TestGetName(){
        assertEquals(allergey.getName(), "AllergyName");
    }

    @Test
    public void TestToString(){
        assertEquals(allergey.toString(), "Allergy AllergyName");
    }
}